object_tangible_loot_loot_schematic_sword_lightsaber_onehanded_gen5_exar_kun_schematic = object_tangible_loot_loot_schematic_shared_sword_lightsaber_onehanded_gen5_exar_kun_schematic:new {
templateType = LOOTSCHEMATIC,
	objectMenuComponent = "LootSchematicMenuComponent",
	attributeListComponent = "LootSchematicAttributeListComponent",
	requiredSkill = "force_discipline_light_saber_master",
	targetDraftSchematic = "object/draft_schematic/weapon/lightsaber/lightsaber_onehanded_gen5_exar_kun.iff",
	targetUseCount = 1,
	noTrade = 1
}
ObjectTemplates: addTemplate(object_tangible_loot_loot_schematic_sword_lightsaber_onehanded_gen5_exar_kun_schematic, "object/tangible/loot/loot_schematic/sword_lightsaber_onehanded_gen5_exar_kun_schematic.iff")